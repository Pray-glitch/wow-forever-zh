-- EnglishLinks：把聊天輸入框裡的連結文字換成英文（連結本身不變，只換方括號裡的名字）。
-- 專業連結（enchant:法術ID）先查法術表；查不到就把「專業: 名稱」的名稱當物品中文名去查。
-- 物品連結用中文名查英文名（完全相同才換，所以帶隨機後綴的綠裝不會被換錯）。
-- /el 開關；按住 Alt 貼連結時不轉換（想貼中文給台灣人看的時候用）。
local SPELL, NAME = EnglishLinks_Spell or {}, EnglishLinks_Name or {}
local PROF = { ["鍊金術"]="Alchemy", ["鍛造"]="Blacksmithing", ["附魔"]="Enchanting", ["工程學"]="Engineering",
  ["製皮"]="Leatherworking", ["裁縫"]="Tailoring", ["烹飪"]="Cooking", ["急救"]="First Aid", ["採礦"]="Mining" }

local function enabled() return not (EnglishLinksDB and EnglishLinksDB.off) end

-- 把一段連結文字換成英文；回傳 nil 表示不用換
local function english(kind, id, text)
  local prof, rest = text:match("^(.-)%s*[:：]%s*(.+)$")
  local pen = prof and PROF[prof]
  if kind == "enchant" or kind == "spell" or kind == "trade" then
    local en = SPELL[tonumber(id)]
    if not en then en = NAME[pen and rest or text] end
    if not en then return nil end
    return pen and (pen .. ": " .. en) or en
  elseif kind == "item" then
    return NAME[text]
  end
end

function EnglishLinks_Convert(msg)
  if not msg or not msg:find("|H", 1, true) then return msg end
  return (msg:gsub("(|H(%a+):(%-?%d+)[^|]*|h%[)(.-)(%]|h)", function(pre, kind, id, text, post)
    local en = english(kind, id, text)
    if en and en ~= text then return pre .. en .. post end
  end))
end

local busy
local function fix(box)
  if busy or not box or not enabled() or IsAltKeyDown() then return end
  local t = box:GetText()
  if not t or t == "" then return end
  local n = EnglishLinks_Convert(t)
  if n ~= t then
    busy = true
    local pos = box:GetCursorPosition()
    box:SetText(n)
    box:SetCursorPosition(math.max(0, pos + (#n - #t)))
    busy = false
  end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
  EnglishLinksDB = EnglishLinksDB or {}
  -- 貼連結之後馬上換（Shift+左鍵）
  if ChatEdit_InsertLink then
    hooksecurefunc("ChatEdit_InsertLink", function()
      local box = ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow()
      if box then fix(box) end
    end)
  end
  -- 保險：輸入框文字變動時也檢查（有些介面插件用自己的方式塞連結）
  for i = 1, (NUM_CHAT_WINDOWS or 10) do
    local box = _G["ChatFrame" .. i .. "EditBox"]
    if box then box:HookScript("OnTextChanged", function(self) fix(self) end) end
  end
end)

SLASH_ENGLISHLINKS1 = "/el"
SLASH_ENGLISHLINKS2 = "/englishlinks"
SlashCmdList["ENGLISHLINKS"] = function()
  EnglishLinksDB = EnglishLinksDB or {}
  EnglishLinksDB.off = not EnglishLinksDB.off
  print("|cffe8c26b連結轉英文|r：" .. (EnglishLinksDB.off and "已關閉（連結維持中文）" or "已開啟（連結會轉成英文）"))
end
